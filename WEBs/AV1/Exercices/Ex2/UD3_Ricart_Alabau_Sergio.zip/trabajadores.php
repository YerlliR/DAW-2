<?php
/**
 * @author Sergio Ricart Alabau
 */

$trabajadores = [
    "Juan" => 1200,
    "Ana" => 1500,
    "Luis" => 1000,
    "Maria" => 1800,
    "Pedro" => 1300
];

